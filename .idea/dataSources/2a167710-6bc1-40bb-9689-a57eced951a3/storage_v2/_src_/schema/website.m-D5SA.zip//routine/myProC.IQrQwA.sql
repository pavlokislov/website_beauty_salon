create
    definer = root@localhost procedure myProC()
BEGIN
    BEGIN
        DECLARE i INT DEFAULT 2;
        WHILE i <= 6
            DO
                INSERT INTO master_schedule(local_date_time, user_id)
                VALUES (TIMESTAMP(CURRENT_DATE + 1, TIME(090000)), i);
                INSERT INTO master_schedule(local_date_time, user_id)
                VALUES (TIMESTAMP(CURRENT_DATE + 1, TIME(093000)), i);
                INSERT INTO master_schedule(local_date_time, user_id)
                VALUES (TIMESTAMP(CURRENT_DATE + 1, TIME(100000)), i);
                INSERT INTO master_schedule(local_date_time, user_id)
                VALUES (TIMESTAMP(CURRENT_DATE + 1, TIME(103000)), i);
                INSERT INTO master_schedule(local_date_time, user_id)
                VALUES (TIMESTAMP(CURRENT_DATE + 1, TIME(110000)), i);
                INSERT INTO master_schedule(local_date_time, user_id)
                VALUES (TIMESTAMP(CURRENT_DATE + 1, TIME(113000)), i);
                INSERT INTO master_schedule(local_date_time, user_id)
                VALUES (TIMESTAMP(CURRENT_DATE + 1, TIME(120000)), i);
                INSERT INTO master_schedule(local_date_time, user_id)
                VALUES (TIMESTAMP(CURRENT_DATE + 1, TIME(123000)), i);
                INSERT INTO master_schedule(local_date_time, user_id)
                VALUES (TIMESTAMP(CURRENT_DATE + 1, TIME(133000)), i);
                INSERT INTO master_schedule(local_date_time, user_id)
                VALUES (TIMESTAMP(CURRENT_DATE + 1, TIME(140000)), i);
                INSERT INTO master_schedule(local_date_time, user_id)
                VALUES (TIMESTAMP(CURRENT_DATE + 1, TIME(143000)), i);
                INSERT INTO master_schedule(local_date_time, user_id)
                VALUES (TIMESTAMP(CURRENT_DATE + 1, TIME(150000)), i);
                INSERT INTO master_schedule(local_date_time, user_id)
                VALUES (TIMESTAMP(CURRENT_DATE + 1, TIME(153000)), i);
                INSERT INTO master_schedule(local_date_time, user_id)
                VALUES (TIMESTAMP(CURRENT_DATE + 1, TIME(160000)), i);
                INSERT INTO master_schedule(local_date_time, user_id)
                VALUES (TIMESTAMP(CURRENT_DATE + 1, TIME(163000)), i);
                INSERT INTO master_schedule(local_date_time, user_id)
                VALUES (TIMESTAMP(CURRENT_DATE + 1, TIME(170000)), i);
                INSERT INTO master_schedule(local_date_time, user_id)
                VALUES (TIMESTAMP(CURRENT_DATE + 1, TIME(173000)), i);
                INSERT INTO master_schedule(local_date_time, user_id)
                VALUES (TIMESTAMP(CURRENT_DATE + 1, TIME(180000)), i);
                INSERT INTO master_schedule(local_date_time, user_id)
                VALUES (TIMESTAMP(CURRENT_DATE + 1, TIME(183000)), i);
                INSERT INTO master_schedule(local_date_time, user_id)
                VALUES (TIMESTAMP(CURRENT_DATE + 1, TIME(190000)), i);
                INSERT INTO master_schedule(local_date_time, user_id)
                VALUES (TIMESTAMP(CURRENT_DATE + 1, TIME(193000)), i);
                INSERT INTO master_schedule(local_date_time, user_id)
                VALUES (TIMESTAMP(CURRENT_DATE + 1, TIME(200000)), i);
                SET i = i + 1;
            END WHILE;
    END;

end;

