create
    definer = root@localhost procedure books()
BEGIN
DECLARE i INT DEFAULT 1;
WHILE i<22 DO
INSERT INTO master_schedule(local_date_time, master_schedule_id)
VALUES (TIMESTAMP(CURRENT_DATE+1, TIME(090000+30*i)), 1);
SET i=i+1;
    END WHILE;
END;

